<?php
/**
 * فرم گزارش کار
 * Work Report Form
 */

require_once 'config.php';
require_once 'dbc.php';
require_once 'header.php';

check_login();

$action = $_GET['action'] ?? 'add';
$reportId = (int)($_GET['id'] ?? 0);
$workOrderId = (int)($_GET['work_order_id'] ?? 0);
$error = '';
$success = '';
$report = null;

// چک مجوز
$canWrite = check_permission('production', PERMISSION_WRITE);
$canApprove = check_permission('production', PERMISSION_FULL);

if ($action === 'view' || $action === 'edit') {
    if (!$reportId) {
        redirect(SITE_URL . '/production.php');
    }
    
    $report = db()->selectOne(
        "SELECT wr.*, wo.work_order_number, wo.title as work_order_title, wo.progress as wo_progress,
         u.fullname as reported_by_name, approver.fullname as approved_by_name
         FROM work_reports wr
         LEFT JOIN work_orders wo ON wo.id = wr.work_order_id
         LEFT JOIN users u ON u.id = wr.reported_by
         LEFT JOIN users approver ON approver.id = wr.approved_by
         WHERE wr.id = :id",
        [':id' => $reportId]
    );
    
    if (!$report) {
        redirect(SITE_URL . '/production.php');
    }
}

// تایید گزارش
if (($_SERVER['REQUEST_METHOD'] === 'POST') && $action === 'approve' && $canApprove) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی. لطفاً مجدداً تلاش کنید.';
    } else {
        $newStatus = sanitize_input($_POST['status']);
        $approvalNotes = sanitize_input($_POST['approval_notes'] ?? '');
        
        db()->beginTransaction();
        
        try {
            db()->update('work_reports', [
                'status' => $newStatus,
                'approved_by' => $_SESSION['user_id'],
                'approved_at' => date('Y-m-d H:i:s'),
                'approval_notes' => $approvalNotes
            ], 'id = :id', [':id' => $reportId]);
            
            // اگر تایید شد، پیشرفت دستور کار را به‌روز کن
            if ($newStatus === 'approved' && $report['work_order_id']) {
                $currentProgress = db()->selectOne(
                    "SELECT progress FROM work_orders WHERE id = :id",
                    [':id' => $report['work_order_id']]
                );
                
                if ($currentProgress) {
                    $newProgress = min(100, $currentProgress['progress'] + $report['progress_percentage']);
                    
                    $updateData = ['progress' => $newProgress];
                    
                    // اگر به 100 رسید، وضعیت را تکمیل کن
                    if ($newProgress >= 100) {
                        $updateData['status'] = 'completed';
                        $updateData['completed_date'] = date('Y-m-d');
                    }
                    
                    db()->update('work_orders', $updateData, 'id = :id', [':id' => $report['work_order_id']]);
                }
            }
            
            // ثبت لاگ
            db()->insert('logs', [
                'user_id' => $_SESSION['user_id'],
                'action' => 'approve_work_report',
                'module' => 'production',
                'record_id' => $reportId,
                'new_data' => json_encode(['status' => $newStatus]),
                'ip_address' => $_SERVER['REMOTE_ADDR']
            ]);
            
            db()->commit();
            
            redirect(SITE_URL . '/work_report.php?action=view&id=' . $reportId . '&msg=approved');
        } catch (Exception $e) {
            db()->rollback();
            $error = 'خطا در انجام عملیات: ' . $e->getMessage();
        }
    }
}

// ذخیره گزارش
if (($_SERVER['REQUEST_METHOD'] === 'POST') && ($action === 'add' || $action === 'edit') && $canWrite) {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی. لطفاً مجدداً تلاش کنید.';
    } else {
        $data = [
            'work_order_id' => (int)($_POST['work_order_id']),
            'report_date' => sanitize_input($_POST['report_date']),
            'work_hours' => (float)($_POST['work_hours']),
            'progress_percentage' => (float)($_POST['progress_percentage']),
            'work_description' => sanitize_input($_POST['work_description']),
            'problems' => sanitize_input($_POST['problems'] ?? ''),
            'next_steps' => sanitize_input($_POST['next_steps'] ?? ''),
            'quality_status' => sanitize_input($_POST['quality_status']),
            'notes' => sanitize_input($_POST['notes'] ?? '')
        ];
        
        // اعتبارسنجی
        if (empty($data['work_order_id']) || empty($data['report_date']) || empty($data['work_description'])) {
            $error = 'دستور کار، تاریخ و شرح کار الزامی است.';
        } elseif ($data['work_hours'] <= 0) {
            $error = 'ساعات کار باید بیشتر از صفر باشد.';
        } elseif ($data['progress_percentage'] < 0 || $data['progress_percentage'] > 100) {
            $error = 'درصد پیشرفت باید بین 0 تا 100 باشد.';
        } else {
            db()->beginTransaction();
            
            try {
                if ($action === 'add') {
                    // تولید شماره گزارش
                    $lastNumber = db()->selectOne(
                        "SELECT report_number FROM work_reports ORDER BY id DESC LIMIT 1"
                    );
                    
                    if ($lastNumber) {
                        $num = (int)substr($lastNumber['report_number'], 3) + 1;
                    } else {
                        $num = 1;
                    }
                    
                    $data['report_number'] = 'WR-' . str_pad($num, 5, '0', STR_PAD_LEFT);
                    $data['reported_by'] = $_SESSION['user_id'];
                    $data['status'] = 'pending';
                    
                    $reportId = db()->insert('work_reports', $data);
                    $logAction = 'add_work_report';
                } else {
                    db()->update('work_reports', $data, 'id = :id', [':id' => $reportId]);
                    $logAction = 'edit_work_report';
                }
                
                // به‌روزرسانی ساعات واقعی دستور کار
                $totalHours = db()->selectOne(
                    "SELECT SUM(work_hours) as total FROM work_reports 
                     WHERE work_order_id = :woid AND status = 'approved'",
                    [':woid' => $data['work_order_id']]
                );
                
                if ($totalHours && $totalHours['total']) {
                    db()->update('work_orders', 
                        ['actual_hours' => $totalHours['total']], 
                        'id = :id', 
                        [':id' => $data['work_order_id']]
                    );
                }
                
                // ثبت لاگ
                db()->insert('logs', [
                    'user_id' => $_SESSION['user_id'],
                    'action' => $logAction,
                    'module' => 'production',
                    'record_id' => $reportId,
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                ]);
                
                db()->commit();
                
                redirect(SITE_URL . '/work_report.php?action=view&id=' . $reportId . '&msg=saved');
            } catch (Exception $e) {
                db()->rollback();
                $error = 'خطا در ذخیره اطلاعات: ' . $e->getMessage();
            }
        }
    }
}

// دریافت لیست دستورات کار فعال
$workOrders = db()->select(
    "SELECT id, work_order_number, title FROM work_orders 
     WHERE status IN ('pending', 'in_progress') ORDER BY created_at DESC"
);

// اگر دستور کار مشخص شده، اطلاعات آن را بگیریم
$selectedWorkOrder = null;
if ($workOrderId && $action === 'add') {
    $selectedWorkOrder = db()->selectOne(
        "SELECT id, work_order_number, title, progress FROM work_orders WHERE id = :id",
        [':id' => $workOrderId]
    );
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php 
        echo $action === 'add' ? 'گزارش کار جدید' : 
             ($action === 'edit' ? 'ویرایش گزارش کار' : 'مشاهده گزارش کار');
    ?> - <?php echo SITE_TITLE; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Tahoma, 'Iranian Sans', Arial, sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 24px;
        }
        
        .btn-back {
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 8px;
            text-decoration: none;
        }
        
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
        }
        
        .alert-success {
            background: #efe;
            color: #3c3;
        }
        
        .form-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .form-section h2 {
            color: #667eea;
            font-size: 18px;
            margin-bottom: 20px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
            font-size: 14px;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: Tahoma, Arial, sans-serif;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .badge-pending { background: #fff3cd; color: #856404; }
        .badge-approved { background: #d4edda; color: #155724; }
        .badge-rejected { background: #f8d7da; color: #721c24; }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .info-box {
            background: #f8f9ff;
            border: 2px solid #667eea;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .info-item:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📝 <?php 
                echo $action === 'add' ? 'گزارش کار جدید' : 
                     ($action === 'edit' ? 'ویرایش گزارش' : 'مشاهده گزارش');
                
                if ($report) {
                    echo ' - ' . h($report['report_number']);
                }
            ?></h1>
            <a href="production.php" class="btn-back">⬅ بازگشت</a>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo h($error); ?></div>
        <?php endif; ?>
        
        <?php if (isset($_GET['msg'])): ?>
            <div class="alert alert-success">
                <?php 
                if ($_GET['msg'] === 'saved') echo 'گزارش با موفقیت ذخیره شد.';
                elseif ($_GET['msg'] === 'approved') echo 'عملیات با موفقیت انجام شد.';
                ?>
            </div>
        <?php endif; ?>
        
        <div class="form-container">
            <?php if ($action === 'approve' && $canApprove): ?>
                <!-- فرم تایید/رد -->
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    
                    <div class="form-section">
                        <h2>بررسی گزارش کار</h2>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>تصمیم</label>
                                <select name="status" required>
                                    <option value="approved">تایید</option>
                                    <option value="rejected">رد</option>
                                </select>
                            </div>
                            
                            <div class="form-group" style="grid-column: 1 / -1;">
                                <label>یادداشت بررسی</label>
                                <textarea name="approval_notes"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">✅ ثبت تصمیم</button>
                        <a href="work_report.php?action=view&id=<?php echo $reportId; ?>" class="btn btn-secondary">انصراف</a>
                    </div>
                </form>
            <?php else: ?>
                <!-- فرم افزودن/ویرایش -->
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    
                    <?php if ($action !== 'add'): ?>
                        <div class="info-box">
                            <div class="info-item">
                                <span>شماره گزارش:</span>
                                <strong><?php echo h($report['report_number']); ?></strong>
                            </div>
                            <div class="info-item">
                                <span>وضعیت:</span>
                                <span class="badge badge-<?php echo $report['status']; ?>">
                                    <?php 
                                    $statuses = ['pending' => 'در انتظار', 'approved' => 'تایید شده', 'rejected' => 'رد شده'];
                                    echo $statuses[$report['status']] ?? $report['status'];
                                    ?>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-section">
                        <h2>اطلاعات گزارش</h2>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>دستور کار *</label>
                                <select name="work_order_id" required <?php echo $action === 'view' ? 'disabled' : ''; ?>>
                                    <option value="">انتخاب کنید</option>
                                    <?php foreach ($workOrders as $wo): ?>
                                        <option value="<?php echo $wo['id']; ?>" 
                                                <?php echo ($report['work_order_id'] ?? $workOrderId) == $wo['id'] ? 'selected' : ''; ?>>
                                            <?php echo h($wo['work_order_number']) . ' - ' . h($wo['title']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label>تاریخ *</label>
                                <input type="date" name="report_date" 
                                       value="<?php echo $report['report_date'] ?? date('Y-m-d'); ?>" 
                                       required 
                                       <?php echo $action === 'view' ? 'readonly' : ''; ?>>
                            </div>
                            
                            <div class="form-group">
                                <label>ساعات کار *</label>
                                <input type="number" name="work_hours" step="0.5" min="0.5" 
                                       value="<?php echo $report['work_hours'] ?? ''; ?>" 
                                       required 
                                       <?php echo $action === 'view' ? 'readonly' : ''; ?>>
                            </div>
                            
                            <div class="form-group">
                                <label>پیشرفت (٪) *</label>
                                <input type="number" name="progress_percentage" step="1" min="0" max="100" 
                                       value="<?php echo $report['progress_percentage'] ?? ''; ?>" 
                                       required 
                                       <?php echo $action === 'view' ? 'readonly' : ''; ?>>
                            </div>
                            
                            <div class="form-group">
                                <label>وضعیت کیفی *</label>
                                <select name="quality_status" required <?php echo $action === 'view' ? 'disabled' : ''; ?>>
                                    <option value="excellent" <?php echo ($report['quality_status'] ?? '') === 'excellent' ? 'selected' : ''; ?>>عالی</option>
                                    <option value="good" <?php echo ($report['quality_status'] ?? '') === 'good' ? 'selected' : ''; ?>>خوب</option>
                                    <option value="acceptable" <?php echo ($report['quality_status'] ?? 'acceptable') === 'acceptable' ? 'selected' : ''; ?>>قابل قبول</option>
                                    <option value="needs_improvement" <?php echo ($report['quality_status'] ?? '') === 'needs_improvement' ? 'selected' : ''; ?>>نیاز به بهبود</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section">
                        <h2>شرح کار و جزئیات</h2>
                        <div class="form-group">
                            <label>شرح کار انجام شده *</label>
                            <textarea name="work_description" required 
                                      <?php echo $action === 'view' ? 'readonly' : ''; ?>><?php echo h($report['work_description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>مشکلات و موانع</label>
                            <textarea name="problems" 
                                      <?php echo $action === 'view' ? 'readonly' : ''; ?>><?php echo h($report['problems'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>اقدامات بعدی</label>
                            <textarea name="next_steps" 
                                      <?php echo $action === 'view' ? 'readonly' : ''; ?>><?php echo h($report['next_steps'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label>یادداشت‌ها</label>
                            <textarea name="notes" 
                                      <?php echo $action === 'view' ? 'readonly' : ''; ?>><?php echo h($report['notes'] ?? ''); ?></textarea>
                        </div>
                    </div>
                    
                    <?php if ($action === 'view' && $report['approved_by']): ?>
                        <div class="form-section">
                            <h2>اطلاعات تایید</h2>
                            <div class="info-box">
                                <div class="info-item">
                                    <span>تاییدکننده:</span>
                                    <strong><?php echo h($report['approved_by_name']); ?></strong>
                                </div>
                                <div class="info-item">
                                    <span>تاریخ تایید:</span>
                                    <strong><?php echo en2fa($report['approved_at']); ?></strong>
                                </div>
                                <?php if ($report['approval_notes']): ?>
                                    <div class="info-item">
                                        <span>یادداشت:</span>
                                        <strong><?php echo h($report['approval_notes']); ?></strong>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-actions">
                        <?php if ($action === 'view'): ?>
                            <?php if ($canWrite && $report['status'] === 'pending'): ?>
                                <a href="work_report.php?action=edit&id=<?php echo $reportId; ?>" class="btn btn-primary">✏️ ویرایش</a>
                            <?php endif; ?>
                            <?php if ($canApprove && $report['status'] === 'pending'): ?>
                                <a href="work_report.php?action=approve&id=<?php echo $reportId; ?>" class="btn btn-success">✅ بررسی و تایید</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <button type="submit" class="btn btn-primary">💾 ذخیره</button>
                        <?php endif; ?>
                        <a href="production.php" class="btn btn-secondary">بازگشت</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php require_once 'footer.php'; ?>