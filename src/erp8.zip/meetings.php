<?php
/**
 * ماژول مدیریت جلسات
 */

require_once 'config.php';
require_once 'dbc.php';

$pageTitle = 'مدیریت جلسات';
require_once 'header.php';

check_login();

if (!check_permission('meetings', PERMISSION_READ)) {
    die('<div class="container"><div class="alert alert-error">شما مجوز دسترسی به این بخش را ندارید.</div></div>');
}

// پارامترهای جستجو و فیلتر
$search = sanitize_input($_GET['search'] ?? '');
$status = sanitize_input($_GET['status'] ?? '');
$dateFrom = sanitize_input($_GET['date_from'] ?? '');
$dateTo = sanitize_input($_GET['date_to'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;

// ساخت کوئری
$sql = "SELECT m.*, 
        u.fullname as creator_name,
        (SELECT COUNT(*) FROM messages WHERE JSON_CONTAINS(m.attendees, CAST(receiver_id AS JSON), '$')) as attendees_count
        FROM meetings m
        LEFT JOIN users u ON u.id = m.created_by
        WHERE 1=1";

$params = [];

if ($search) {
    $sql .= " AND (m.title LIKE :search OR m.meeting_number LIKE :search OR m.location LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

if ($status) {
    $sql .= " AND m.status = :status";
    $params[':status'] = $status;
}

if ($dateFrom) {
    $sql .= " AND m.meeting_date >= :date_from";
    $params[':date_from'] = $dateFrom;
}

if ($dateTo) {
    $sql .= " AND m.meeting_date <= :date_to";
    $params[':date_to'] = $dateTo;
}

$sql .= " ORDER BY m.meeting_date DESC, m.meeting_time DESC";

// دریافت داده‌ها با صفحه‌بندی
$result = db()->paginate($sql, $params, $page, $perPage);
$meetings = $result['data'];
$totalPages = $result['total_pages'];

// آمار جلسات
$stats = [
    'total' => db()->count('meetings'),
    'scheduled' => db()->count('meetings', 'status = "scheduled"'),
    'completed' => db()->count('meetings', 'status = "completed"'),
    'cancelled' => db()->count('meetings', 'status = "cancelled"'),
    'today' => db()->count('meetings', 'meeting_date = CURDATE()')
];
?>

<style>
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 15px;
        transition: transform 0.3s;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.15);
    }
    
    .stat-icon {
        font-size: 40px;
        width: 60px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 12px;
    }
    
    .stat-icon.total {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    
    .stat-icon.scheduled {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }
    
    .stat-icon.completed {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }
    
    .stat-icon.cancelled {
        background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
    }
    
    .stat-icon.today {
        background: linear-gradient(135deg, #30cfd0 0%, #330867 100%);
    }
    
    .stat-info h3 {
        font-size: 28px;
        color: #333;
        margin-bottom: 5px;
    }
    
    .stat-info p {
        color: #666;
        font-size: 14px;
    }
    
    .page-header {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-bottom: 25px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 15px;
    }
    
    .page-header h1 {
        color: #2c3e50;
        font-size: 28px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .btn {
        padding: 12px 24px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        cursor: pointer;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        transition: all 0.3s;
        font-family: inherit;
    }
    
    .btn-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    
    .filters-panel {
        background: white;
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        margin-bottom: 25px;
    }
    
    .filters-form {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        align-items: end;
    }
    
    .form-group {
        display: flex;
        flex-direction: column;
    }
    
    .form-group label {
        margin-bottom: 5px;
        color: #555;
        font-size: 14px;
        font-weight: 500;
    }
    
    .form-group input,
    .form-group select {
        padding: 10px 12px;
        border: 2px solid #e0e0e0;
        border-radius: 8px;
        font-size: 14px;
        font-family: inherit;
        transition: border-color 0.3s;
    }
    
    .form-group input:focus,
    .form-group select:focus {
        outline: none;
        border-color: #667eea;
    }
    
    .meetings-grid {
        display: grid;
        gap: 20px;
    }
    
    .meeting-card {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        padding: 20px;
        transition: all 0.3s;
        border-right: 5px solid #667eea;
    }
    
    .meeting-card:hover {
        transform: translateX(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }
    
    .meeting-card.scheduled {
        border-right-color: #f093fb;
    }
    
    .meeting-card.completed {
        border-right-color: #4facfe;
    }
    
    .meeting-card.cancelled {
        border-right-color: #fa709a;
        opacity: 0.7;
    }
    
    .meeting-header {
        display: flex;
        justify-content: space-between;
        align-items: start;
        margin-bottom: 15px;
    }
    
    .meeting-title {
        flex: 1;
    }
    
    .meeting-title h3 {
        font-size: 20px;
        color: #2c3e50;
        margin-bottom: 5px;
    }
    
    .meeting-number {
        font-size: 12px;
        color: #999;
    }
    
    .meeting-status {
        padding: 6px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
    }
    
    .meeting-status.scheduled {
        background: #fff3e0;
        color: #f57c00;
    }
    
    .meeting-status.in-progress {
        background: #e3f2fd;
        color: #1976d2;
    }
    
    .meeting-status.completed {
        background: #e8f5e9;
        color: #388e3c;
    }
    
    .meeting-status.cancelled {
        background: #ffebee;
        color: #d32f2f;
    }
    
    .meeting-details {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-bottom: 15px;
    }
    
    .detail-item {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;
        color: #666;
    }
    
    .detail-icon {
        font-size: 18px;
    }
    
    .meeting-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 15px;
        border-top: 1px solid #f0f0f0;
    }
    
    .attendees-count {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #666;
        font-size: 14px;
    }
    
    .actions {
        display: flex;
        gap: 8px;
    }
    
    .btn-sm {
        padding: 8px 14px;
        font-size: 13px;
        border-radius: 6px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        transition: all 0.2s;
        border: none;
        cursor: pointer;
    }
    
    .btn-view {
        background: #4caf50;
        color: white;
    }
    
    .btn-edit {
        background: #2196f3;
        color: white;
    }
    
    .btn-delete {
        background: #f44336;
        color: white;
    }
    
    .btn-sm:hover {
        transform: translateY(-2px);
        box-shadow: 0 3px 8px rgba(0,0,0,0.2);
    }
    
    .no-data {
        background: white;
        padding: 60px 20px;
        border-radius: 12px;
        text-align: center;
        color: #999;
    }
    
    .no-data-icon {
        font-size: 64px;
        margin-bottom: 20px;
    }
    
    .pagination {
        display: flex;
        justify-content: center;
        gap: 10px;
        margin-top: 30px;
    }
    
    .page-link {
        padding: 10px 16px;
        border: 2px solid #667eea;
        border-radius: 8px;
        color: #667eea;
        text-decoration: none;
        transition: all 0.3s;
        font-weight: 500;
    }
    
    .page-link:hover,
    .page-link.active {
        background: #667eea;
        color: white;
        transform: translateY(-2px);
    }
    
    @media (max-width: 768px) {
        .page-header {
            flex-direction: column;
            align-items: stretch;
        }
        
        .filters-form {
            grid-template-columns: 1fr;
        }
        
        .meeting-details {
            grid-template-columns: 1fr;
        }
        
        .meeting-footer {
            flex-direction: column;
            gap: 10px;
            align-items: stretch;
        }
    }
</style>

<div class="container">
    <!-- آمار -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon total">🤝</div>
            <div class="stat-info">
                <h3><?php echo en2fa($stats['total']); ?></h3>
                <p>کل جلسات</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon scheduled">📅</div>
            <div class="stat-info">
                <h3><?php echo en2fa($stats['scheduled']); ?></h3>
                <p>برنامه‌ریزی شده</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon completed">✅</div>
            <div class="stat-info">
                <h3><?php echo en2fa($stats['completed']); ?></h3>
                <p>برگزار شده</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon cancelled">❌</div>
            <div class="stat-info">
                <h3><?php echo en2fa($stats['cancelled']); ?></h3>
                <p>لغو شده</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon today">⏰</div>
            <div class="stat-info">
                <h3><?php echo en2fa($stats['today']); ?></h3>
                <p>جلسات امروز</p>
            </div>
        </div>
    </div>
    
    <!-- هدر صفحه -->
    <div class="page-header">
        <h1>
            <span>🤝</span>
            مدیریت جلسات
        </h1>
        <?php if (check_permission('meetings', PERMISSION_WRITE)): ?>
            <a href="meeting.php?action=add" class="btn btn-primary">
                ➕ برنامه‌ریزی جلسه جدید
            </a>
        <?php endif; ?>
    </div>
    
    <!-- فیلترها -->
    <div class="filters-panel">
        <form method="GET" action="" class="filters-form">
            <div class="form-group">
                <label>🔍 جستجو</label>
                <input type="text" name="search" placeholder="عنوان، شماره، مکان..." 
                       value="<?php echo h($search); ?>">
            </div>
            
            <div class="form-group">
                <label>📊 وضعیت</label>
                <select name="status">
                    <option value="">همه</option>
                    <option value="scheduled" <?php echo $status === 'scheduled' ? 'selected' : ''; ?>>برنامه‌ریزی شده</option>
                    <option value="in_progress" <?php echo $status === 'in_progress' ? 'selected' : ''; ?>>در حال برگزاری</option>
                    <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>برگزار شده</option>
                    <option value="cancelled" <?php echo $status === 'cancelled' ? 'selected' : ''; ?>>لغو شده</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>📅 از تاریخ</label>
                <input type="date" name="date_from" value="<?php echo h($dateFrom); ?>">
            </div>
            
            <div class="form-group">
                <label>📅 تا تاریخ</label>
                <input type="date" name="date_to" value="<?php echo h($dateTo); ?>">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary">🔍 اعمال فیلتر</button>
            </div>
        </form>
    </div>
    
    <!-- لیست جلسات -->
    <div class="meetings-grid">
        <?php if (count($meetings) > 0): ?>
            <?php foreach ($meetings as $meeting): ?>
                <?php
                $statusLabels = [
                    'scheduled' => 'برنامه‌ریزی شده',
                    'in_progress' => 'در حال برگزاری',
                    'completed' => 'برگزار شده',
                    'cancelled' => 'لغو شده'
                ];
                
                $attendees = json_decode($meeting['attendees'] ?? '[]', true);
                $attendeesCount = is_array($attendees) ? count($attendees) : 0;
                ?>
                
                <div class="meeting-card <?php echo h($meeting['status']); ?>">
                    <div class="meeting-header">
                        <div class="meeting-title">
                            <h3><?php echo h($meeting['title']); ?></h3>
                            <div class="meeting-number">
                                شماره: <?php echo h($meeting['meeting_number']); ?>
                            </div>
                        </div>
                        <span class="meeting-status <?php echo h($meeting['status']); ?>">
                            <?php echo $statusLabels[$meeting['status']] ?? $meeting['status']; ?>
                        </span>
                    </div>
                    
                    <div class="meeting-details">
                        <div class="detail-item">
                            <span class="detail-icon">📅</span>
                            <span><?php echo en2fa(date('Y/m/d', strtotime($meeting['meeting_date']))); ?></span>
                        </div>
                        
                        <div class="detail-item">
                            <span class="detail-icon">⏰</span>
                            <span><?php echo en2fa(date('H:i', strtotime($meeting['meeting_time']))); ?></span>
                        </div>
                        
                        <?php if ($meeting['duration_minutes']): ?>
                        <div class="detail-item">
                            <span class="detail-icon">⌛</span>
                            <span><?php echo en2fa($meeting['duration_minutes']); ?> دقیقه</span>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($meeting['location']): ?>
                        <div class="detail-item">
                            <span class="detail-icon">📍</span>
                            <span><?php echo h($meeting['location']); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="meeting-footer">
                        <div class="attendees-count">
                            <span>👥</span>
                            <span><?php echo en2fa($attendeesCount); ?> شرکت‌کننده</span>
                        </div>
                        
                        <div class="actions">
                            <a href="meeting.php?action=view&id=<?php echo $meeting['id']; ?>" 
                               class="btn-sm btn-view" title="مشاهده">
                                👁️ مشاهده
                            </a>
                            <?php if (check_permission('meetings', PERMISSION_WRITE)): ?>
                                <a href="meeting.php?action=edit&id=<?php echo $meeting['id']; ?>" 
                                   class="btn-sm btn-edit" title="ویرایش">
                                    ✏️ ویرایش
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="no-data">
                <div class="no-data-icon">🤝</div>
                <h3>هیچ جلسه‌ای یافت نشد</h3>
                <p>برای شروع، یک جلسه جدید برنامه‌ریزی کنید</p>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- صفحه‌بندی -->
    <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>" 
                   class="page-link">⮜ قبلی</a>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>" 
                   class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                    <?php echo en2fa($i); ?>
                </a>
            <?php endfor; ?>
            
            <?php if ($page < $totalPages): ?>
                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&date_from=<?php echo urlencode($dateFrom); ?>&date_to=<?php echo urlencode($dateTo); ?>" 
                   class="page-link">بعدی ⮞</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once 'footer.php'; ?>