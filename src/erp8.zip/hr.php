<?php
/**
 * داشبورد منابع انسانی
 */

require_once 'config.php';
require_once 'dbc.php';

$pageTitle = 'منابع انسانی';
require_once 'header.php';

check_login();

if (!check_permission('hr', PERMISSION_READ)) {
    die('<div class="container"><div class="alert alert-error">شما مجوز دسترسی به این بخش را ندارید.</div></div>');
}

// آمار کلی
$stats = [
    'total_employees' => db()->count('hr_employees', 'status = "active"'),
    'full_time' => db()->count('hr_employees', 'status = "active" AND employment_type = "full_time"'),
    'part_time' => db()->count('hr_employees', 'status = "active" AND employment_type = "part_time"'),
    'contract' => db()->count('hr_employees', 'status = "active" AND employment_type = "contract"'),
    'on_leave' => db()->count('hr_leaves', 'status = "approved" AND start_date <= CURDATE() AND end_date >= CURDATE()'),
    'pending_leaves' => db()->count('hr_leaves', 'status = "pending"'),
    'pending_loans' => db()->count('hr_loans', 'status = "pending"'),
    'birthdays_this_month' => 0
];

// تولدهای این ماه (از جدول contacts)
$birthdayResult = db()->selectOne(
    "SELECT COUNT(*) as count FROM contacts c
     INNER JOIN hr_employees e ON e.contact_id = c.id
     WHERE e.status = 'active' 
     AND MONTH(STR_TO_DATE(c.birth_date, '%Y-%m-%d')) = MONTH(CURDATE())"
);
$stats['birthdays_this_month'] = $birthdayResult ? (int)$birthdayResult['count'] : 0;

// حضور امروز
$todayAttendance = db()->select(
    "SELECT 
        COUNT(DISTINCT employee_id) as present,
        SUM(CASE WHEN check_out IS NULL THEN 1 ELSE 0 END) as still_in
     FROM hr_attendance 
     WHERE attendance_date = CURDATE()"
);
$attendanceToday = $todayAttendance[0] ?? ['present' => 0, 'still_in' => 0];

// درخواست‌های در انتظار
$pendingRequests = db()->select(
    "SELECT 'leave' as type, COUNT(*) as count FROM hr_leaves WHERE status = 'pending'
     UNION ALL
     SELECT 'loan', COUNT(*) FROM hr_loans WHERE status = 'pending'
     UNION ALL
     SELECT 'evaluation', COUNT(*) FROM hr_evaluations WHERE status = 'pending'"
);

// تولدهای امروز
$todayBirthdays = db()->select(
    "SELECT e.id, c.name, e.employee_code, c.birth_date
     FROM hr_employees e
     INNER JOIN contacts c ON c.id = e.contact_id
     WHERE e.status = 'active'
     AND DAY(STR_TO_DATE(c.birth_date, '%Y-%m-%d')) = DAY(CURDATE())
     AND MONTH(STR_TO_DATE(c.birth_date, '%Y-%m-%d')) = MONTH(CURDATE())
     LIMIT 5"
);

// کارمندان جدید (30 روز اخیر)
$newEmployees = db()->select(
    "SELECT e.id, c.name, e.employee_code, e.employment_date, e.position
     FROM hr_employees e
     INNER JOIN contacts c ON c.id = e.contact_id
     WHERE e.employment_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     ORDER BY e.employment_date DESC
     LIMIT 5"
);

// نمودار حضور هفته اخیر
$weekAttendance = db()->select(
    "SELECT 
        attendance_date,
        COUNT(DISTINCT employee_id) as present_count
     FROM hr_attendance
     WHERE attendance_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
     GROUP BY attendance_date
     ORDER BY attendance_date"
);
?>

<style>
    .hr-dashboard {
        padding: 20px;
    }
    
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .stat-card {
        background: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 20px;
        transition: transform 0.3s, box-shadow 0.3s;
        cursor: pointer;
        text-decoration: none;
        color: inherit;
    }
    
    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }
    
    .stat-icon {
        width: 70px;
        height: 70px;
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 35px;
        flex-shrink: 0;
    }
    
    .stat-icon.employees { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    .stat-icon.full-time { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
    .stat-icon.part-time { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
    .stat-icon.contract { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
    .stat-icon.leave { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); }
    .stat-icon.pending { background: linear-gradient(135deg, #30cfd0 0%, #330867 100%); }
    .stat-icon.birthday { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); }
    .stat-icon.attendance { background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%); }
    
    .stat-info {
        flex: 1;
    }
    
    .stat-value {
        font-size: 36px;
        font-weight: bold;
        color: #2c3e50;
        line-height: 1;
        margin-bottom: 8px;
    }
    
    .stat-label {
        color: #666;
        font-size: 14px;
        font-weight: 500;
    }
    
    .content-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .panel {
        background: white;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        overflow: hidden;
    }
    
    .panel-header {
        padding: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .panel-header h3 {
        font-size: 18px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .panel-body {
        padding: 20px;
    }
    
    .quick-actions {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 15px;
    }
    
    .action-btn {
        padding: 20px;
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border: 2px solid #e0e0e0;
        border-radius: 12px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s;
        text-decoration: none;
        color: #2c3e50;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
    }
    
    .action-btn:hover {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
    }
    
    .action-icon {
        font-size: 32px;
    }
    
    .action-label {
        font-size: 13px;
        font-weight: 500;
    }
    
    .list-item {
        padding: 15px;
        border-bottom: 1px solid #f0f0f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background 0.2s;
    }
    
    .list-item:hover {
        background: #f8f9fa;
    }
    
    .list-item:last-child {
        border-bottom: none;
    }
    
    .item-info {
        flex: 1;
    }
    
    .item-name {
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 5px;
    }
    
    .item-meta {
        font-size: 13px;
        color: #666;
    }
    
    .badge {
        padding: 5px 12px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 600;
    }
    
    .badge.pending { background: #fff3e0; color: #f57c00; }
    .badge.approved { background: #e8f5e9; color: #388e3c; }
    .badge.active { background: #e3f2fd; color: #1976d2; }
    
    .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #999;
    }
    
    .empty-icon {
        font-size: 48px;
        margin-bottom: 15px;
    }
    
    @media (max-width: 768px) {
        .content-grid {
            grid-template-columns: 1fr;
        }
        
        .quick-actions {
            grid-template-columns: repeat(2, 1fr);
        }
    }
</style>

<div class="hr-dashboard">
    <!-- آمار کلی -->
    <div class="stats-grid">
        <a href="employees.php" class="stat-card">
            <div class="stat-icon employees">👥</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($stats['total_employees']); ?></div>
                <div class="stat-label">کل پرسنل فعال</div>
            </div>
        </a>
        
        <a href="employees.php?type=full_time" class="stat-card">
            <div class="stat-icon full-time">💼</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($stats['full_time']); ?></div>
                <div class="stat-label">تمام وقت</div>
            </div>
        </a>
        
        <a href="employees.php?type=part_time" class="stat-card">
            <div class="stat-icon part-time">⏰</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($stats['part_time']); ?></div>
                <div class="stat-label">پاره وقت</div>
            </div>
        </a>
        
        <a href="employees.php?type=contract" class="stat-card">
            <div class="stat-icon contract">📝</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($stats['contract']); ?></div>
                <div class="stat-label">قراردادی</div>
            </div>
        </a>
        
        <a href="leaves.php?status=approved&active=1" class="stat-card">
            <div class="stat-icon leave">🏖️</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($stats['on_leave']); ?></div>
                <div class="stat-label">در مرخصی</div>
            </div>
        </a>
        
        <a href="leaves.php?status=pending" class="stat-card">
            <div class="stat-icon pending">⏳</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($stats['pending_leaves']); ?></div>
                <div class="stat-label">مرخصی در انتظار</div>
            </div>
        </a>
        
        <div class="stat-card">
            <div class="stat-icon birthday">🎂</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($stats['birthdays_this_month']); ?></div>
                <div class="stat-label">تولد این ماه</div>
            </div>
        </div>
        
        <a href="attendance.php?date=<?php echo date('Y-m-d'); ?>" class="stat-card">
            <div class="stat-icon attendance">✅</div>
            <div class="stat-info">
                <div class="stat-value"><?php echo en2fa($attendanceToday['present']); ?></div>
                <div class="stat-label">حاضر امروز</div>
            </div>
        </a>
    </div>
    
    <!-- دسترسی سریع -->
    <div class="panel" style="margin-bottom: 30px;">
        <div class="panel-header">
            <h3>⚡ دسترسی سریع</h3>
        </div>
        <div class="panel-body">
            <div class="quick-actions">
                <a href="employee.php?action=add" class="action-btn">
                    <div class="action-icon">➕</div>
                    <div class="action-label">استخدام جدید</div>
                </a>
                
                <a href="attendance.php" class="action-btn">
                    <div class="action-icon">📋</div>
                    <div class="action-label">حضور و غیاب</div>
                </a>
                
                <a href="leave_request.php" class="action-btn">
                    <div class="action-icon">🏖️</div>
                    <div class="action-label">درخواست مرخصی</div>
                </a>
                
                <a href="salary_calculation.php" class="action-btn">
                    <div class="action-icon">💰</div>
                    <div class="action-label">محاسبه حقوق</div>
                </a>
                
                <a href="loan_request.php" class="action-btn">
                    <div class="action-icon">🏦</div>
                    <div class="action-label">درخواست وام</div>
                </a>
                
                <a href="hr_evaluations.php" class="action-btn">
                    <div class="action-icon">📊</div>
                    <div class="action-label">ارزیابی عملکرد</div>
                </a>
                
                <a href="hr_contracts.php" class="action-btn">
                    <div class="action-icon">📄</div>
                    <div class="action-label">قراردادها</div>
                </a>
                
                <a href="hr_reports.php" class="action-btn">
                    <div class="action-icon">📈</div>
                    <div class="action-label">گزارش‌ها</div>
                </a>
            </div>
        </div>
    </div>
    
    <div class="content-grid">
        <!-- تولدهای امروز -->
        <div class="panel">
            <div class="panel-header">
                <h3>🎂 تولدهای امروز</h3>
                <span><?php echo en2fa(count($todayBirthdays)); ?> نفر</span>
            </div>
            <div class="panel-body">
                <?php if (count($todayBirthdays) > 0): ?>
                    <?php foreach ($todayBirthdays as $birthday): ?>
                        <div class="list-item">
                            <div class="item-info">
                                <div class="item-name"><?php echo h($birthday['name']); ?></div>
                                <div class="item-meta">
                                    کد پرسنلی: <?php echo h($birthday['employee_code']); ?>
                                </div>
                            </div>
                            <a href="employee.php?id=<?php echo $birthday['id']; ?>" class="badge active">
                                مشاهده
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon">🎉</div>
                        <p>امروز تولدی نیست</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- کارمندان جدید -->
        <div class="panel">
            <div class="panel-header">
                <h3>👋 استخدام‌های اخیر</h3>
                <span>30 روز اخیر</span>
            </div>
            <div class="panel-body">
                <?php if (count($newEmployees) > 0): ?>
                    <?php foreach ($newEmployees as $emp): ?>
                        <div class="list-item">
                            <div class="item-info">
                                <div class="item-name"><?php echo h($emp['name']); ?></div>
                                <div class="item-meta">
                                    <?php echo h($emp['position']); ?> • 
                                    <?php echo en2fa(date('Y/m/d', strtotime($emp['employment_date']))); ?>
                                </div>
                            </div>
                            <a href="employee.php?id=<?php echo $emp['id']; ?>" class="badge active">
                                مشاهده
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon">👥</div>
                        <p>استخدام جدیدی در 30 روز اخیر نداشته‌اید</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- مرخصی‌های در انتظار -->
        <div class="panel">
            <div class="panel-header">
                <h3>⏳ مرخصی‌های در انتظار</h3>
                <span><?php echo en2fa($stats['pending_leaves']); ?> درخواست</span>
            </div>
            <div class="panel-body">
                <?php 
                $pendingLeaves = db()->select(
                    "SELECT l.*, c.name, e.employee_code
                     FROM hr_leaves l
                     INNER JOIN hr_employees e ON e.id = l.employee_id
                     INNER JOIN contacts c ON c.id = e.contact_id
                     WHERE l.status = 'pending'
                     ORDER BY l.created_at DESC
                     LIMIT 5"
                );
                
                if (count($pendingLeaves) > 0): ?>
                    <?php foreach ($pendingLeaves as $leave): ?>
                        <div class="list-item">
                            <div class="item-info">
                                <div class="item-name"><?php echo h($leave['name']); ?></div>
                                <div class="item-meta">
                                    <?php echo en2fa($leave['days']); ?> روز • 
                                    از <?php echo en2fa(date('Y/m/d', strtotime($leave['start_date']))); ?>
                                </div>
                            </div>
                            <a href="leave_request.php?id=<?php echo $leave['id']; ?>" class="badge pending">
                                بررسی
                            </a>
                        </div>
                    <?php endforeach; ?>
                    
                    <div style="text-align: center; padding-top: 15px; border-top: 1px solid #f0f0f0; margin-top: 15px;">
                        <a href="leaves.php?status=pending" style="color: #667eea; text-decoration: none; font-size: 13px;">
                            مشاهده همه →
                        </a>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon">✅</div>
                        <p>درخواست مرخصی در انتظار وجود ندارد</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- وام‌های در انتظار -->
        <div class="panel">
            <div class="panel-header">
                <h3>🏦 درخواست‌های وام</h3>
                <span><?php echo en2fa($stats['pending_loans']); ?> درخواست</span>
            </div>
            <div class="panel-body">
                <?php 
                $pendingLoans = db()->select(
                    "SELECT l.*, c.name, e.employee_code
                     FROM hr_loans l
                     INNER JOIN hr_employees e ON e.id = l.employee_id
                     INNER JOIN contacts c ON c.id = e.contact_id
                     WHERE l.status = 'pending'
                     ORDER BY l.created_at DESC
                     LIMIT 5"
                );
                
                if (count($pendingLoans) > 0): ?>
                    <?php foreach ($pendingLoans as $loan): ?>
                        <div class="list-item">
                            <div class="item-info">
                                <div class="item-name"><?php echo h($loan['name']); ?></div>
                                <div class="item-meta">
                                    مبلغ: <?php echo en2fa(number_format($loan['amount'])); ?> ریال •
                                    <?php echo en2fa($loan['installments']); ?> قسط
                                </div>
                            </div>
                            <a href="loan_request.php?id=<?php echo $loan['id']; ?>" class="badge pending">
                                بررسی
                            </a>
                        </div>
                    <?php endforeach; ?>
                    
                    <div style="text-align: center; padding-top: 15px; border-top: 1px solid #f0f0f0; margin-top: 15px;">
                        <a href="loans.php?status=pending" style="color: #667eea; text-decoration: none; font-size: 13px;">
                            مشاهده همه →
                        </a>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <div class="empty-icon">✅</div>
                        <p>درخواست وام در انتظار وجود ندارد</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>