<?php
/**
 * لیست ITP (Inspection and Test Plan) - برنامه بازرسی و آزمون
 */

require_once 'config.php';
require_once 'dbc.php';
require_once 'header.php';

check_login();

if (!check_permission('qc', PERMISSION_READ)) {
    die('شما مجوز دسترسی به این بخش را ندارید.');
}

// پارامترهای جستجو و فیلتر
$search = sanitize_input($_GET['search'] ?? '');
$status = sanitize_input($_GET['status'] ?? '');
$project_id = (int)($_GET['project_id'] ?? 0);
$category = sanitize_input($_GET['category'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

// ساخت کوئری
$sql = "SELECT i.*, 
        p.title as project_name, p.code as project_code,
        prod.name as product_name, prod.code as product_code,
        u.fullname as created_by_name,
        u2.fullname as approved_by_name,
        (SELECT COUNT(*) FROM itp_checkpoints WHERE itp_id = i.id) as checkpoints_count,
        (SELECT COUNT(*) FROM itp_checkpoints WHERE itp_id = i.id AND status = 'completed') as completed_count
        FROM itps i
        LEFT JOIN projects p ON p.id = i.project_id
        LEFT JOIN products prod ON prod.id = i.product_id
        LEFT JOIN users u ON u.id = i.created_by
        LEFT JOIN users u2 ON u2.id = i.approved_by
        WHERE 1=1";

$params = [];

if ($search) {
    $sql .= " AND (i.itp_number LIKE :search OR i.title LIKE :search OR i.description LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

if ($status) {
    $sql .= " AND i.status = :status";
    $params[':status'] = $status;
}

if ($project_id > 0) {
    $sql .= " AND i.project_id = :project_id";
    $params[':project_id'] = $project_id;
}

if ($category) {
    $sql .= " AND i.category = :category";
    $params[':category'] = $category;
}

$sql .= " ORDER BY i.created_at DESC";

// دریافت داده‌ها با صفحه‌بندی
$result = db()->paginate($sql, $params, $page, $perPage);
$itps = $result['data'];
$totalPages = $result['total_pages'];

// دریافت لیست پروژه‌ها
$projects = db()->select("SELECT id, code, title FROM projects WHERE status != 'cancelled' ORDER BY created_at DESC LIMIT 50");

// دریافت دسته‌بندی‌ها
$categories = db()->select("SELECT DISTINCT category FROM itps WHERE category IS NOT NULL AND category != '' ORDER BY category");

// آمار کلی
$stats = db()->selectOne("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft,
        SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
    FROM itps
");
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لیست ITP - <?php echo SITE_TITLE; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Tahoma, 'Iranian Sans', Arial, sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        
        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        
        .stat-icon.total { background: linear-gradient(135deg, #a8e063 0%, #56ab2f 100%); }
        .stat-icon.draft { background: linear-gradient(135deg, #ffd89b 0%, #19547b 100%); }
        .stat-icon.active { background: linear-gradient(135deg, #09c6f9 0%, #045de9 100%); }
        .stat-icon.progress { background: linear-gradient(135deg, #f5af19 0%, #f12711 100%); }
        .stat-icon.completed { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        
        .stat-info h3 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 5px;
        }
        
        .stat-info p {
            color: #7f8c8d;
            font-size: 13px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #a8e063 0%, #56ab2f 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(86, 171, 47, 0.4);
        }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .filters form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            margin-bottom: 5px;
            color: #555;
            font-size: 13px;
            font-weight: bold;
        }
        
        .form-group input,
        .form-group select {
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: Tahoma, Arial, sans-serif;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #56ab2f;
        }
        
        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: linear-gradient(135deg, #a8e063 0%, #56ab2f 100%);
            color: white;
        }
        
        th {
            padding: 15px 12px;
            text-align: right;
            font-weight: bold;
            font-size: 13px;
        }
        
        td {
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 13px;
        }
        
        tbody tr {
            transition: background 0.2s;
        }
        
        tbody tr:hover {
            background: #f8fff8;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .badge-draft {
            background: #ffeaa7;
            color: #d63031;
        }
        
        .badge-active {
            background: #74b9ff;
            color: #0984e3;
        }
        
        .badge-in_progress {
            background: #fab1a0;
            color: #e17055;
        }
        
        .badge-completed {
            background: #55efc4;
            color: #00b894;
        }
        
        .badge-on_hold {
            background: #dfe6e9;
            color: #636e72;
        }
        
        .progress-bar {
            width: 100%;
            height: 20px;
            background: #ecf0f1;
            border-radius: 10px;
            overflow: hidden;
            position: relative;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #56ab2f 0%, #a8e063 100%);
            transition: width 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 11px;
            font-weight: bold;
        }
        
        .actions {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 11px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.2s;
            border: none;
            cursor: pointer;
        }
        
        .btn-view {
            background: #4caf50;
            color: white;
        }
        
        .btn-edit {
            background: #2196f3;
            color: white;
        }
        
        .btn-print {
            background: #ff9800;
            color: white;
        }
        
        .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .btn-sm:hover {
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(0,0,0,0.2);
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            padding: 20px;
        }
        
        .page-link {
            padding: 8px 15px;
            border: 2px solid #56ab2f;
            border-radius: 6px;
            color: #56ab2f;
            text-decoration: none;
            transition: all 0.2s;
            font-size: 13px;
        }
        
        .page-link:hover,
        .page-link.active {
            background: #56ab2f;
            color: white;
        }
        
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .no-data svg {
            width: 120px;
            height: 120px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .itp-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .itp-number {
            font-weight: bold;
            color: #2c3e50;
            font-size: 14px;
        }
        
        .itp-title {
            color: #7f8c8d;
            font-size: 12px;
        }
        
        .project-info {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
        }
        
        .project-code {
            background: #e8f5e9;
            padding: 2px 8px;
            border-radius: 4px;
            font-weight: bold;
            color: #2e7d32;
        }
        
        .category-badge {
            background: #f3e5f5;
            color: #7b1fa2;
            padding: 4px 10px;
            border-radius: 8px;
            font-size: 11px;
            font-weight: bold;
        }
        
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .stats {
                grid-template-columns: 1fr;
            }
            
            .filters form {
                grid-template-columns: 1fr;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 1100px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                ✅ لیست ITP (Inspection & Test Plan)
            </h1>
            <?php if (check_permission('qc', PERMISSION_WRITE)): ?>
                <a href="itp.php?action=add" class="btn btn-primary">
                    ➕ ایجاد ITP جدید
                </a>
            <?php endif; ?>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-icon total">📋</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['total']); ?></h3>
                    <p>کل برنامه‌ها</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon draft">📝</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['draft']); ?></h3>
                    <p>پیش‌نویس</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon active">⚡</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['active']); ?></h3>
                    <p>فعال</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon progress">⏳</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['in_progress']); ?></h3>
                    <p>در حال اجرا</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon completed">✅</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['completed']); ?></h3>
                    <p>تکمیل شده</p>
                </div>
            </div>
        </div>
        
        <div class="filters">
            <form method="GET" action="">
                <div class="form-group">
                    <label>جستجو</label>
                    <input type="text" name="search" placeholder="شماره، عنوان، توضیحات..." 
                           value="<?php echo h($search); ?>">
                </div>
                
                <div class="form-group">
                    <label>وضعیت</label>
                    <select name="status">
                        <option value="">همه</option>
                        <option value="draft" <?php echo $status === 'draft' ? 'selected' : ''; ?>>پیش‌نویس</option>
                        <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>فعال</option>
                        <option value="in_progress" <?php echo $status === 'in_progress' ? 'selected' : ''; ?>>در حال اجرا</option>
                        <option value="completed" <?php echo $status === 'completed' ? 'selected' : ''; ?>>تکمیل شده</option>
                        <option value="on_hold" <?php echo $status === 'on_hold' ? 'selected' : ''; ?>>متوقف شده</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>پروژه</label>
                    <select name="project_id">
                        <option value="">همه پروژه‌ها</option>
                        <?php foreach ($projects as $project): ?>
                            <option value="<?php echo $project['id']; ?>" 
                                    <?php echo $project_id == $project['id'] ? 'selected' : ''; ?>>
                                [<?php echo h($project['code']); ?>] <?php echo h($project['title']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>دسته‌بندی</label>
                    <select name="category">
                        <option value="">همه دسته‌ها</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo h($cat['category']); ?>" 
                                    <?php echo $category === $cat['category'] ? 'selected' : ''; ?>>
                                <?php echo h($cat['category']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">🔍 جستجو</button>
                </div>
            </form>
        </div>
        
        <div class="table-container">
            <?php if (count($itps) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>شماره ITP</th>
                            <th>عنوان</th>
                            <th>پروژه</th>
                            <th>دسته‌بندی</th>
                            <th>پیشرفت</th>
                            <th>وضعیت</th>
                            <th>ایجادکننده</th>
                            <th>تاییدکننده</th>
                            <th>تاریخ ایجاد</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($itps as $itp): ?>
                            <tr>
                                <td>
                                    <div class="itp-info">
                                        <span class="itp-number"><?php echo h($itp['itp_number']); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="itp-title"><?php echo h($itp['title']); ?></div>
                                </td>
                                <td>
                                    <?php if ($itp['project_name']): ?>
                                        <div class="project-info">
                                            <span class="project-code"><?php echo h($itp['project_code']); ?></span>
                                            <span><?php echo h(mb_substr($itp['project_name'], 0, 25)); ?></span>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: #999;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($itp['category']): ?>
                                        <span class="category-badge"><?php echo h($itp['category']); ?></span>
                                    <?php else: ?>
                                        <span style="color: #999;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $progress = $itp['checkpoints_count'] > 0 
                                        ? round(($itp['completed_count'] / $itp['checkpoints_count']) * 100) 
                                        : 0;
                                    ?>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: <?php echo $progress; ?>%">
                                            <?php if ($progress > 15): ?>
                                                <?php echo en2fa($progress); ?>%
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <small style="color: #7f8c8d; margin-top: 4px; display: block;">
                                        <?php echo en2fa($itp['completed_count']); ?> از <?php echo en2fa($itp['checkpoints_count']); ?> نقطه
                                    </small>
                                </td>
                                <td>
                                    <?php
                                    $statusLabels = [
                                        'draft' => 'پیش‌نویس',
                                        'active' => 'فعال',
                                        'in_progress' => 'در حال اجرا',
                                        'completed' => 'تکمیل شده',
                                        'on_hold' => 'متوقف شده'
                                    ];
                                    $statusClass = 'badge-' . str_replace('_', '_', $itp['status']);
                                    ?>
                                    <span class="badge <?php echo $statusClass; ?>">
                                        <?php echo $statusLabels[$itp['status']] ?? $itp['status']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="font-size: 12px;"><?php echo h($itp['created_by_name']); ?></span>
                                </td>
                                <td>
                                    <span style="font-size: 12px;">
                                        <?php echo $itp['approved_by_name'] ? h($itp['approved_by_name']) : '-'; ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="font-size: 12px; color: #7f8c8d;">
                                        <?php echo en2fa(date('Y/m/d', strtotime($itp['created_at']))); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="itp.php?action=view&id=<?php echo $itp['id']; ?>" 
                                           class="btn-sm btn-view" title="مشاهده">👁️</a>
                                        <a href="itp.php?action=print&id=<?php echo $itp['id']; ?>" 
                                           class="btn-sm btn-print" title="چاپ" target="_blank">🖨️</a>
                                        <?php if (check_permission('qc', PERMISSION_WRITE) && $itp['status'] !== 'completed'): ?>
                                            <a href="itp.php?action=edit&id=<?php echo $itp['id']; ?>" 
                                               class="btn-sm btn-edit" title="ویرایش">✏️</a>
                                        <?php endif; ?>
                                        <?php if (check_permission('qc', PERMISSION_FULL) && $itp['status'] === 'draft'): ?>
                                            <button onclick="deleteITP(<?php echo $itp['id']; ?>)" 
                                                    class="btn-sm btn-delete" title="حذف">🗑️</button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&project_id=<?php echo $project_id; ?>&category=<?php echo urlencode($category); ?>" 
                               class="page-link">❮ قبلی</a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&project_id=<?php echo $project_id; ?>&category=<?php echo urlencode($category); ?>" 
                               class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                                <?php echo en2fa($i); ?>
                            </a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&project_id=<?php echo $project_id; ?>&category=<?php echo urlencode($category); ?>" 
                               class="page-link">بعدی ❯</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="no-data">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                    </svg>
                    <h3>هیچ برنامه بازرسی یافت نشد</h3>
                    <p>برای ایجاد ITP جدید از دکمه بالای صفحه استفاده کنید.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function deleteITP(id) {
            if (confirm('آیا از حذف این برنامه بازرسی اطمینان دارید؟\nتوجه: این عملیات قابل بازگشت نیست.')) {
                window.location.href = 'itp.php?action=delete&id=' + id;
            }
        }
    </script>
</body>
</html>

<?php require_once 'footer.php'; ?>