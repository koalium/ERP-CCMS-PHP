<?php
/**
 * فرم گزارش کار روزانه
 */

require_once 'config.php';
require_once 'dbc.php';
require_once 'header.php';

check_login();

if (!check_permission('projects', PERMISSION_READ)) {
    die('شما مجوز دسترسی به این بخش را ندارید.');
}

$action = sanitize_input($_GET['action'] ?? 'add');
$reportId = (int)($_GET['id'] ?? 0);
$taskId = (int)($_GET['task_id'] ?? 0);

$report = null;
$task = null;
$project = null;
$error = '';
$success = '';

// بارگذاری گزارش
if ($reportId) {
    $report = db()->selectOne("SELECT * FROM work_reports WHERE id = :id", [':id' => $reportId]);
    if (!$report) {
        die('گزارش یافت نشد.');
    }
    $taskId = $report['task_id'];
}

// بارگذاری وظیفه
if ($taskId) {
    $task = db()->selectOne("SELECT * FROM tasks WHERE id = :id", [':id' => $taskId]);
    if (!$task) {
        die('وظیفه یافت نشد.');
    }
    
    $project = db()->selectOne("SELECT * FROM projects WHERE id = :id", [':id' => $task['project_id']]);
}

// پردازش فرم
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action !== 'view') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'خطای امنیتی.';
    } else {
        $data = [
            'task_id' => $taskId,
            'project_id' => $task['project_id'],
            'report_date' => sanitize_input($_POST['report_date'] ?? date('Y-m-d')),
            'work_description' => sanitize_input($_POST['work_description'] ?? ''),
            'hours_spent' => (float)($_POST['hours_spent'] ?? 0),
            'progress_percentage' => (int)($_POST['progress_percentage'] ?? 0),
            'issues' => sanitize_input($_POST['issues'] ?? ''),
            'next_steps' => sanitize_input($_POST['next_steps'] ?? '')
        ];
        
        // اعتبارسنجی
        if (empty($data['work_description'])) {
            $error = 'شرح کار انجام شده الزامی است.';
        } elseif ($data['hours_spent'] <= 0) {
            $error = 'ساعات کار باید بیشتر از صفر باشد.';
        } elseif ($data['progress_percentage'] < 0 || $data['progress_percentage'] > 100) {
            $error = 'درصد پیشرفت باید بین 0 تا 100 باشد.';
        } else {
            if ($action === 'add') {
                $data['created_by'] = $_SESSION['user_id'];
                $newId = db()->insert('work_reports', $data);
                
                if ($newId) {
                    // به‌روزرسانی پیشرفت وظیفه
                    db()->update('tasks', 
                        ['progress' => $data['progress_percentage']], 
                        'id = :id', 
                        [':id' => $taskId]
                    );
                    
                    // محاسبه ساعات واقعی
                    $totalHours = db()->selectOne(
                        "SELECT SUM(hours_spent) as total FROM work_reports WHERE task_id = :tid",
                        [':tid' => $taskId]
                    );
                    
                    db()->update('tasks',
                        ['actual_hours' => $totalHours['total']],
                        'id = :id',
                        [':id' => $taskId]
                    );
                    
                    db()->insert('logs', [
                        'user_id' => $_SESSION['user_id'],
                        'action' => 'create',
                        'module' => 'work_reports',
                        'record_id' => $newId,
                        'new_data' => json_encode($data),
                        'ip_address' => $_SERVER['REMOTE_ADDR']
                    ]);
                    
                    redirect(SITE_URL . '/work_report.php?id=' . $newId . '&success=1');
                } else {
                    $error = 'خطا در ثبت گزارش.';
                }
            } else {
                $updated = db()->update('work_reports', $data, 'id = :id', [':id' => $reportId]);
                
                if ($updated !== false) {
                    db()->insert('logs', [
                        'user_id' => $_SESSION['user_id'],
                        'action' => 'update',
                        'module' => 'work_reports',
                        'record_id' => $reportId,
                        'old_data' => json_encode($report),
                        'new_data' => json_encode($data),
                        'ip_address' => $_SERVER['REMOTE_ADDR']
                    ]);
                    
                    $success = 'گزارش با موفقیت به‌روزرسانی شد.';
                    $report = db()->selectOne("SELECT * FROM work_reports WHERE id = :id", [':id' => $reportId]);
                } else {
                    $error = 'خطا در به‌روزرسانی گزارش.';
                }
            }
        }
    }
}

if (isset($_GET['success'])) {
    $success = 'گزارش کار با موفقیت ثبت شد.';
}

// لیست گزارش‌های قبلی
$previousReports = [];
if ($taskId) {
    $previousReports = db()->select(
        "SELECT w.*, u.fullname as creator_name 
         FROM work_reports w 
         LEFT JOIN users u ON u.id = w.created_by 
         WHERE w.task_id = :tid 
         ORDER BY w.report_date DESC 
         LIMIT 5",
        [':tid' => $taskId]
    );
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>گزارش کار روزانه - <?php echo SITE_TITLE; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Tahoma, 'Iranian Sans', Arial, sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        
        .container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .breadcrumb {
            display: flex;
            gap: 10px;
            align-items: center;
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        
        .breadcrumb a {
            color: #667eea;
            text-decoration: none;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 24px;
            margin-bottom: 15px;
        }
        
        .task-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-right: 4px solid #667eea;
        }
        
        .task-info h3 {
            color: #2c3e50;
            margin-bottom: 8px;
        }
        
        .task-info p {
            color: #666;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-error {
            background: #fee;
            color: #c33;
            border: 1px solid #fcc;
        }
        
        .alert-success {
            background: #efe;
            color: #3c3;
            border: 1px solid #cfc;
        }
        
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        .form-group label {
            margin-bottom: 8px;
            color: #555;
            font-size: 14px;
            font-weight: bold;
        }
        
        .form-group label span {
            color: #f44336;
        }
        
        .form-group input,
        .form-group textarea {
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: Tahoma, Arial, sans-serif;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        .progress-indicator {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .progress-bar {
            flex: 1;
            height: 10px;
            background: #e0e0e0;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4caf50 0%, #45a049 100%);
            transition: width 0.3s;
        }
        
        .progress-value {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
            min-width: 60px;
            text-align: center;
        }
        
        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            padding-top: 20px;
            border-top: 2px solid #f0f0f0;
        }
        
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .previous-reports {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .previous-reports h2 {
            color: #2c3e50;
            margin-bottom: 20px;
        }
        
        .report-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-right: 4px solid #667eea;
        }
        
        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .report-date {
            font-weight: bold;
            color: #2c3e50;
        }
        
        .report-author {
            color: #666;
            font-size: 13px;
        }
        
        .report-content {
            color: #555;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        
        .report-stats {
            display: flex;
            gap: 20px;
            font-size: 13px;
            color: #666;
        }
        
        .report-stats span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .tip-box {
            background: #fff3e0;
            border-right: 4px solid #ff9800;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .tip-box h3 {
            color: #f57c00;
            font-size: 14px;
            margin-bottom: 8px;
        }
        
        .tip-box ul {
            margin-right: 20px;
            color: #e65100;
            font-size: 13px;
            line-height: 1.8;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="breadcrumb">
                <a href="projects.php">پروژه‌ها</a>
                <?php if ($project): ?>
                    <span>›</span>
                    <a href="project.php?action=view&id=<?php echo $project['id']; ?>"><?php echo h($project['title']); ?></a>
                <?php endif; ?>
                <?php if ($task): ?>
                    <span>›</span>
                    <a href="task.php?action=view&id=<?php echo $task['id']; ?>"><?php echo h($task['title']); ?></a>
                <?php endif; ?>
                <span>›</span>
                <span>گزارش کار</span>
            </div>
            <h1>📝 گزارش کار روزانه</h1>
            
            <?php if ($task): ?>
                <div class="task-info">
                    <h3><?php echo h($task['title']); ?></h3>
                    <p>
                        <strong>پروژه:</strong> <?php echo h($project['code'] . ' - ' . $project['title']); ?><br>
                        <strong>پیشرفت فعلی:</strong> <?php echo en2fa($task['progress']); ?>% |
                        <strong>ساعات صرف شده:</strong> <?php echo en2fa($task['actual_hours'] ?? 0); ?> ساعت
                    </p>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo h($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo h($success); ?></div>
        <?php endif; ?>
        
        <div class="tip-box">
            <h3>💡 نکات مهم در ثبت گزارش کار:</h3>
            <ul>
                <li>شرح کار را به صورت دقیق و کامل بنویسید</li>
                <li>ساعات کار واقعی را وارد کنید</li>
                <li>درصد پیشرفت را با توجه به کل وظیفه محاسبه کنید</li>
                <li>مشکلات و موانع را حتماً ذکر کنید</li>
                <li>برنامه کار فردا را مشخص کنید</li>
            </ul>
        </div>
        
        <div class="form-container">
            <form method="POST" action="" id="reportForm">
                <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>تاریخ گزارش <span>*</span></label>
                        <input type="date" name="report_date" required 
                               value="<?php echo h($report['report_date'] ?? date('Y-m-d')); ?>"
                               max="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>ساعات کار <span>*</span></label>
                        <input type="number" name="hours_spent" required 
                               min="0.5" max="24" step="0.5"
                               value="<?php echo h($report['hours_spent'] ?? ''); ?>"
                               placeholder="مثال: 8 یا 4.5">
                    </div>
                    
                    <div class="form-group full-width">
                        <label>شرح کار انجام شده <span>*</span></label>
                        <textarea name="work_description" required 
                                  placeholder="شرح دقیق کارهایی که امروز انجام دادید..."><?php echo h($report['work_description'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <label>درصد پیشرفت وظیفه <span>*</span></label>
                        <div class="progress-indicator">
                            <div class="progress-bar">
                                <div class="progress-fill" id="progressBar" style="width: <?php echo $report['progress_percentage'] ?? 0; ?>%"></div>
                            </div>
                            <div class="progress-value" id="progressValue"><?php echo en2fa($report['progress_percentage'] ?? 0); ?>%</div>
                        </div>
                        <input type="range" name="progress_percentage" 
                               min="0" max="100" step="5"
                               value="<?php echo $report['progress_percentage'] ?? 0; ?>"
                               id="progressSlider"
                               style="width: 100%; margin-top: 10px;">
                    </div>
                    
                    <div class="form-group full-width">
                        <label>مشکلات و موانع</label>
                        <textarea name="issues" 
                                  placeholder="مشکلات و موانعی که با آن مواجه شدید..."><?php echo h($report['issues'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <label>برنامه کاری بعدی</label>
                        <textarea name="next_steps" 
                                  placeholder="کارهایی که قرار است در روز بعد انجام دهید..."><?php echo h($report['next_steps'] ?? ''); ?></textarea>
                    </div>
                </div>
                
                <div class="form-actions">
                    <a href="task.php?action=view&id=<?php echo $taskId; ?>" class="btn btn-secondary">↩ بازگشت</a>
                    <button type="submit" class="btn btn-primary">
                        <?php echo $action === 'add' ? '📝 ثبت گزارش' : '💾 ذخیره تغییرات'; ?>
                    </button>
                </div>
            </form>
        </div>
        
        <?php if (count($previousReports) > 0): ?>
            <div class="previous-reports">
                <h2>📋 گزارش‌های قبلی (5 مورد اخیر)</h2>
                
                <?php foreach ($previousReports as $pr): ?>
                    <div class="report-item">
                        <div class="report-header">
                            <span class="report-date">📅 <?php echo en2fa($pr['report_date']); ?></span>
                            <span class="report-author">👤 <?php echo h($pr['creator_name']); ?></span>
                        </div>
                        <div class="report-content">
                            <?php echo h($pr['work_description']); ?>
                        </div>
                        <div class="report-stats">
                            <span>⏱️ <?php echo en2fa($pr['hours_spent']); ?> ساعت</span>
                            <span>📊 پیشرفت: <?php echo en2fa($pr['progress_percentage']); ?>%</span>
                        </div>
                        <?php if ($pr['issues']): ?>
                            <div style="margin-top: 10px; padding: 10px; background: #ffebee; border-radius: 6px; font-size: 13px;">
                                <strong>⚠️ مشکلات:</strong> <?php echo h($pr['issues']); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        const slider = document.getElementById('progressSlider');
        const progressBar = document.getElementById('progressBar');
        const progressValue = document.getElementById('progressValue');
        
        slider.addEventListener('input', function() {
            const value = this.value;
            progressBar.style.width = value + '%';
            progressValue.textContent = convertToFarsi(value) + '%';
        });
        
        function convertToFarsi(num) {
            const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            return num.toString().split('').map(d => farsiDigits[parseInt(d)] || d).join('');
        }
    </script>
</body>
</html>

<?php require_once 'footer.php'; ?>