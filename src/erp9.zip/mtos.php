<?php
/**
 * لیست MTO (Material Take-Off) - برداشت مواد
 */

require_once 'config.php';
require_once 'dbc.php';
require_once 'header.php';

check_login();

if (!check_permission('engineering', PERMISSION_READ)) {
    die('شما مجوز دسترسی به این بخش را ندارید.');
}

// پارامترهای جستجو و فیلتر
$search = sanitize_input($_GET['search'] ?? '');
$status = sanitize_input($_GET['status'] ?? '');
$project_id = (int)($_GET['project_id'] ?? 0);
$product_id = (int)($_GET['product_id'] ?? 0);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

// ساخت کوئری
$sql = "SELECT m.*, 
        p.title as project_name, p.code as project_code,
        prod.name as product_name, prod.code as product_code,
        u.fullname as created_by_name,
        u2.fullname as approved_by_name,
        (SELECT COUNT(*) FROM mto_items WHERE mto_id = m.id) as items_count,
        (SELECT SUM(quantity * unit_price) FROM mto_items WHERE mto_id = m.id) as total_value
        FROM mtos m
        LEFT JOIN projects p ON p.id = m.project_id
        LEFT JOIN products prod ON prod.id = m.product_id
        LEFT JOIN users u ON u.id = m.created_by
        LEFT JOIN users u2 ON u2.id = m.approved_by
        WHERE 1=1";

$params = [];

if ($search) {
    $sql .= " AND (m.mto_number LIKE :search OR m.title LIKE :search OR m.description LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

if ($status) {
    $sql .= " AND m.status = :status";
    $params[':status'] = $status;
}

if ($project_id > 0) {
    $sql .= " AND m.project_id = :project_id";
    $params[':project_id'] = $project_id;
}

if ($product_id > 0) {
    $sql .= " AND m.product_id = :product_id";
    $params[':product_id'] = $product_id;
}

$sql .= " ORDER BY m.created_at DESC";

// دریافت داده‌ها با صفحه‌بندی
$result = db()->paginate($sql, $params, $page, $perPage);
$mtos = $result['data'];
$totalPages = $result['total_pages'];

// دریافت لیست پروژه‌ها برای فیلتر
$projects = db()->select("SELECT id, code, title FROM projects WHERE status != 'cancelled' ORDER BY created_at DESC LIMIT 50");

// دریافت لیست محصولات برای فیلتر
$products = db()->select("SELECT id, code, name FROM products WHERE status = 'active' ORDER BY name LIMIT 50");

// آمار کلی
$stats = db()->selectOne("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft,
        SUM(CASE WHEN status = 'review' THEN 1 ELSE 0 END) as review,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'issued' THEN 1 ELSE 0 END) as issued
    FROM mtos
");
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لیست MTO - <?php echo SITE_TITLE; ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Tahoma, 'Iranian Sans', Arial, sans-serif;
            background: #f5f7fa;
            direction: rtl;
        }
        
        .container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        .header h1 {
            color: #2c3e50;
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        
        .stat-icon.total { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .stat-icon.draft { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
        .stat-icon.review { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
        .stat-icon.approved { background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); }
        .stat-icon.issued { background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); }
        
        .stat-info h3 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 5px;
        }
        
        .stat-info p {
            color: #7f8c8d;
            font-size: 13px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .filters {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .filters form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            margin-bottom: 5px;
            color: #555;
            font-size: 13px;
            font-weight: bold;
        }
        
        .form-group input,
        .form-group select {
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: Tahoma, Arial, sans-serif;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        th {
            padding: 15px 12px;
            text-align: right;
            font-weight: bold;
            font-size: 13px;
        }
        
        td {
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 13px;
        }
        
        tbody tr {
            transition: background 0.2s;
        }
        
        tbody tr:hover {
            background: #f8f9fa;
        }
        
        .badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .badge-draft {
            background: #ffeaa7;
            color: #d63031;
        }
        
        .badge-review {
            background: #74b9ff;
            color: #0984e3;
        }
        
        .badge-approved {
            background: #55efc4;
            color: #00b894;
        }
        
        .badge-issued {
            background: #a29bfe;
            color: #6c5ce7;
        }
        
        .badge-rejected {
            background: #ff7675;
            color: #d63031;
        }
        
        .actions {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        
        .btn-sm {
            padding: 6px 12px;
            font-size: 11px;
            border-radius: 6px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.2s;
            border: none;
            cursor: pointer;
        }
        
        .btn-view {
            background: #4caf50;
            color: white;
        }
        
        .btn-edit {
            background: #2196f3;
            color: white;
        }
        
        .btn-print {
            background: #ff9800;
            color: white;
        }
        
        .btn-delete {
            background: #f44336;
            color: white;
        }
        
        .btn-sm:hover {
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(0,0,0,0.2);
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            padding: 20px;
        }
        
        .page-link {
            padding: 8px 15px;
            border: 2px solid #667eea;
            border-radius: 6px;
            color: #667eea;
            text-decoration: none;
            transition: all 0.2s;
            font-size: 13px;
        }
        
        .page-link:hover,
        .page-link.active {
            background: #667eea;
            color: white;
        }
        
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .no-data svg {
            width: 120px;
            height: 120px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .mto-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        
        .mto-number {
            font-weight: bold;
            color: #2c3e50;
            font-size: 14px;
        }
        
        .mto-title {
            color: #7f8c8d;
            font-size: 12px;
        }
        
        .project-info {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
        }
        
        .project-code {
            background: #ecf0f1;
            padding: 2px 8px;
            border-radius: 4px;
            font-weight: bold;
            color: #2c3e50;
        }
        
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: stretch;
            }
            
            .stats {
                grid-template-columns: 1fr;
            }
            
            .filters form {
                grid-template-columns: 1fr;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 1000px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                📊 لیست MTO (Material Take-Off)
            </h1>
            <?php if (check_permission('engineering', PERMISSION_WRITE)): ?>
                <a href="mto.php?action=add" class="btn btn-primary">
                    ➕ ایجاد MTO جدید
                </a>
            <?php endif; ?>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-icon total">📊</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['total']); ?></h3>
                    <p>کل MTO ها</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon draft">📝</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['draft']); ?></h3>
                    <p>پیش‌نویس</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon review">🔍</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['review']); ?></h3>
                    <p>در حال بررسی</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon approved">✅</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['approved']); ?></h3>
                    <p>تایید شده</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon issued">📤</div>
                <div class="stat-info">
                    <h3><?php echo en2fa($stats['issued']); ?></h3>
                    <p>صادر شده</p>
                </div>
            </div>
        </div>
        
        <div class="filters">
            <form method="GET" action="">
                <div class="form-group">
                    <label>جستجو</label>
                    <input type="text" name="search" placeholder="شماره، عنوان، توضیحات..." 
                           value="<?php echo h($search); ?>">
                </div>
                
                <div class="form-group">
                    <label>وضعیت</label>
                    <select name="status">
                        <option value="">همه</option>
                        <option value="draft" <?php echo $status === 'draft' ? 'selected' : ''; ?>>پیش‌نویس</option>
                        <option value="review" <?php echo $status === 'review' ? 'selected' : ''; ?>>در حال بررسی</option>
                        <option value="approved" <?php echo $status === 'approved' ? 'selected' : ''; ?>>تایید شده</option>
                        <option value="issued" <?php echo $status === 'issued' ? 'selected' : ''; ?>>صادر شده</option>
                        <option value="rejected" <?php echo $status === 'rejected' ? 'selected' : ''; ?>>رد شده</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>پروژه</label>
                    <select name="project_id">
                        <option value="">همه پروژه‌ها</option>
                        <?php foreach ($projects as $project): ?>
                            <option value="<?php echo $project['id']; ?>" 
                                    <?php echo $project_id == $project['id'] ? 'selected' : ''; ?>>
                                [<?php echo h($project['code']); ?>] <?php echo h($project['title']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>محصول</label>
                    <select name="product_id">
                        <option value="">همه محصولات</option>
                        <?php foreach ($products as $product): ?>
                            <option value="<?php echo $product['id']; ?>" 
                                    <?php echo $product_id == $product['id'] ? 'selected' : ''; ?>>
                                [<?php echo h($product['code']); ?>] <?php echo h($product['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">🔍 جستجو</button>
                </div>
            </form>
        </div>
        
        <div class="table-container">
            <?php if (count($mtos) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>شماره MTO</th>
                            <th>عنوان</th>
                            <th>پروژه</th>
                            <th>محصول</th>
                            <th>تعداد اقلام</th>
                            <th>مبلغ کل</th>
                            <th>وضعیت</th>
                            <th>ایجادکننده</th>
                            <th>تاییدکننده</th>
                            <th>تاریخ ایجاد</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($mtos as $mto): ?>
                            <tr>
                                <td>
                                    <div class="mto-info">
                                        <span class="mto-number"><?php echo h($mto['mto_number']); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="mto-title"><?php echo h($mto['title']); ?></div>
                                </td>
                                <td>
                                    <?php if ($mto['project_name']): ?>
                                        <div class="project-info">
                                            <span class="project-code"><?php echo h($mto['project_code']); ?></span>
                                            <span><?php echo h(mb_substr($mto['project_name'], 0, 30)); ?></span>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: #999;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($mto['product_name']): ?>
                                        <span style="font-size: 12px;">
                                            [<?php echo h($mto['product_code']); ?>] 
                                            <?php echo h(mb_substr($mto['product_name'], 0, 25)); ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #999;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong style="color: #2c3e50;"><?php echo en2fa($mto['items_count']); ?></strong>
                                </td>
                                <td>
                                    <?php if ($mto['total_value']): ?>
                                        <strong style="color: #27ae60;">
                                            <?php echo en2fa(number_format($mto['total_value'])); ?> ریال
                                        </strong>
                                    <?php else: ?>
                                        <span style="color: #999;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $statusLabels = [
                                        'draft' => 'پیش‌نویس',
                                        'review' => 'در حال بررسی',
                                        'approved' => 'تایید شده',
                                        'issued' => 'صادر شده',
                                        'rejected' => 'رد شده'
                                    ];
                                    $statusClass = 'badge-' . $mto['status'];
                                    ?>
                                    <span class="badge <?php echo $statusClass; ?>">
                                        <?php echo $statusLabels[$mto['status']] ?? $mto['status']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="font-size: 12px;"><?php echo h($mto['created_by_name']); ?></span>
                                </td>
                                <td>
                                    <span style="font-size: 12px;">
                                        <?php echo $mto['approved_by_name'] ? h($mto['approved_by_name']) : '-'; ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="font-size: 12px; color: #7f8c8d;">
                                        <?php echo en2fa(date('Y/m/d', strtotime($mto['created_at']))); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <a href="mto.php?action=view&id=<?php echo $mto['id']; ?>" 
                                           class="btn-sm btn-view" title="مشاهده">👁️</a>
                                        <a href="mto.php?action=print&id=<?php echo $mto['id']; ?>" 
                                           class="btn-sm btn-print" title="چاپ" target="_blank">🖨️</a>
                                        <?php if (check_permission('engineering', PERMISSION_WRITE) && $mto['status'] !== 'issued'): ?>
                                            <a href="mto.php?action=edit&id=<?php echo $mto['id']; ?>" 
                                               class="btn-sm btn-edit" title="ویرایش">✏️</a>
                                        <?php endif; ?>
                                        <?php if (check_permission('engineering', PERMISSION_FULL) && $mto['status'] === 'draft'): ?>
                                            <button onclick="deleteMTO(<?php echo $mto['id']; ?>)" 
                                                    class="btn-sm btn-delete" title="حذف">🗑️</button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&project_id=<?php echo $project_id; ?>&product_id=<?php echo $product_id; ?>" 
                               class="page-link">❮ قبلی</a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&project_id=<?php echo $project_id; ?>&product_id=<?php echo $product_id; ?>" 
                               class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                                <?php echo en2fa($i); ?>
                            </a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status); ?>&project_id=<?php echo $project_id; ?>&product_id=<?php echo $product_id; ?>" 
                               class="page-link">بعدی ❯</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="no-data">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M9 2v2H7v2H5v2H3v2H1v10h22V10h-2V8h-2V6h-2V4h-2V2h-2v2h-2V2H9zm0 2h2v2h2v2h2v2h2v2h2v8H3v-8h2v-2h2V8h2V6h2V4z"/>
                    </svg>
                    <h3>هیچ MTO یافت نشد</h3>
                    <p>برای ایجاد MTO جدید از دکمه بالای صفحه استفاده کنید.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        function deleteMTO(id) {
            if (confirm('آیا از حذف این MTO اطمینان دارید؟\nتوجه: این عملیات قابل بازگشت نیست.')) {
                window.location.href = 'mto.php?action=delete&id=' + id;
            }
        }
    </script>
</body>
</html>

<?php require_once 'footer.php'; ?>