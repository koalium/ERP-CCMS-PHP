<?php
/**
 * داشبورد انبارداری
 */

require_once 'config.php';
require_once 'dbc.php';
require_once 'header.php';

check_login();

if (!check_permission('warehouse', PERMISSION_READ)) {
    die('شما مجوز دسترسی به بخش انبارداری را ندارید.');
}

// دریافت آمار انبار
$warehouseStats = [
    'total_warehouses' => db()->count('warehouses', 'is_active = 1'),
    'total_items' => db()->count('warehouse_items', 'is_active = 1'),
    'low_stock_items' => db()->count('warehouse_items', 'current_stock <= min_stock AND is_active = 1'),
    'out_of_stock' => db()->count('warehouse_items', 'current_stock = 0 AND is_active = 1'),
    'transactions_today' => db()->count('warehouse_transactions', 'transaction_date = CURDATE()'),
    'pending_requests' => db()->count('warehouse_transactions', "status = 'pending'"),
];

// لیست انبارها
$warehouses = db()->select(
    "SELECT w.*, u.fullname as manager_name,
     (SELECT COUNT(*) FROM warehouse_items WHERE is_active = 1) as total_items,
     (SELECT COUNT(DISTINCT item_id) FROM warehouse_transactions WHERE warehouse_id = w.id AND transaction_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)) as active_items_week
     FROM warehouses w
     LEFT JOIN users u ON u.id = w.manager_user_id
     WHERE w.is_active = 1
     ORDER BY w.created_at"
);

// اقلام با موجودی کم
$lowStockItems = db()->select(
    "SELECT wi.*, 
     (SELECT SUM(CASE WHEN wt.type = 'in' THEN wt.quantity ELSE -wt.quantity END) 
      FROM warehouse_transactions wt 
      WHERE wt.item_id = wi.id AND wt.status = 'completed') as calculated_stock
     FROM warehouse_items wi
     WHERE wi.is_active = 1 
     AND wi.current_stock <= wi.min_stock
     AND wi.current_stock > 0
     ORDER BY (wi.current_stock / NULLIF(wi.min_stock, 1)) ASC
     LIMIT 10"
);

// اقلام تمام شده
$outOfStockItems = db()->select(
    "SELECT * FROM warehouse_items 
     WHERE is_active = 1 
     AND current_stock = 0
     ORDER BY name
     LIMIT 10"
);

// آخرین تراکنش‌ها
$recentTransactions = db()->select(
    "SELECT wt.*, 
     w.name as warehouse_name,
     wi.name as item_name,
     wi.unit,
     u.fullname as requested_by_name,
     u2.fullname as approved_by_name
     FROM warehouse_transactions wt
     LEFT JOIN warehouses w ON w.id = wt.warehouse_id
     LEFT JOIN warehouse_items wi ON wi.id = wt.item_id
     LEFT JOIN users u ON u.id = wt.requested_by
     LEFT JOIN users u2 ON u2.id = wt.approved_by
     ORDER BY wt.created_at DESC
     LIMIT 15"
);

// درخواست‌های در انتظار
$pendingRequests = db()->select(
    "SELECT wt.*, 
     w.name as warehouse_name,
     wi.name as item_name,
     wi.unit,
     wi.current_stock,
     u.fullname as requested_by_name,
     p.title as project_name
     FROM warehouse_transactions wt
     LEFT JOIN warehouses w ON w.id = wt.warehouse_id
     LEFT JOIN warehouse_items wi ON wi.id = wt.item_id
     LEFT JOIN users u ON u.id = wt.requested_by
     LEFT JOIN projects p ON p.id = wt.project_id
     WHERE wt.status = 'pending'
     ORDER BY wt.created_at DESC"
);

// محاسبه ارزش کل موجودی
$totalInventoryValue = db()->selectOne(
    "SELECT SUM(current_stock * unit_price) as total_value
     FROM warehouse_items 
     WHERE is_active = 1"
);

// آمار تراکنش‌های هفته اخیر
$weeklyStats = db()->selectOne(
    "SELECT 
        SUM(CASE WHEN type = 'in' THEN 1 ELSE 0 END) as inputs,
        SUM(CASE WHEN type = 'out' THEN 1 ELSE 0 END) as outputs,
        SUM(CASE WHEN type = 'transfer' THEN 1 ELSE 0 END) as transfers
     FROM warehouse_transactions 
     WHERE transaction_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
     AND status = 'completed'"
);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد انبارداری - <?php echo SITE_TITLE; ?></title>
    <style>
        .warehouse-container {
            max-width: 1600px;
            margin: 0 auto;
            padding: 30px 20px;
        }
        
        .warehouse-header {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            box-shadow: 0 5px 20px rgba(243, 156, 18, 0.3);
        }
        
        .warehouse-header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card h3 {
            font-size: 36px;
            margin-bottom: 10px;
            color: #2c3e50;
        }
        
        .stat-card.warning h3 {
            color: #f39c12;
        }
        
        .stat-card.danger h3 {
            color: #e74c3c;
        }
        
        /* Warehouse Cards */
        .warehouses-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .warehouse-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-right: 4px solid #f39c12;
            transition: transform 0.3s;
        }
        
        .warehouse-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        
        .warehouse-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        .warehouse-name {
            font-size: 20px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .warehouse-info {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #f0f0f0;
        }
        
        .warehouse-stat {
            text-align: center;
        }
        
        .warehouse-stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #f39c12;
        }
        
        .warehouse-stat-label {
            font-size: 12px;
            color: #7f8c8d;
        }
        
        /* Alert Cards */
        .alert-section {
            margin-bottom: 30px;
        }
        
        .alert-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
        }
        
        .alert-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .alert-header {
            padding: 15px 20px;
            font-weight: bold;
            color: white;
        }
        
        .alert-header.warning {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
        }
        
        .alert-header.danger {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        }
        
        .alert-body {
            padding: 20px;
            max-height: 400px;
            overflow-y: auto;
        }
        
        .alert-item {
            padding: 15px;
            border-right: 4px solid #f39c12;
            background: #fff8e1;
            margin-bottom: 10px;
            border-radius: 6px;
        }
        
        .alert-item.danger {
            border-right-color: #e74c3c;
            background: #ffebee;
        }
        
        .alert-item-name {
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .alert-item-info {
            font-size: 13px;
            color: #7f8c8d;
            display: flex;
            justify-content: space-between;
        }
        
        .stock-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .progress-bar {
            height: 6px;
            background: #e0e0e0;
            border-radius: 3px;
            overflow: hidden;
            flex: 1;
        }
        
        .progress-fill {
            height: 100%;
            transition: width 0.3s;
        }
        
        .progress-fill.low {
            background: linear-gradient(90deg, #f39c12 0%, #e67e22 100%);
        }
        
        .progress-fill.critical {
            background: linear-gradient(90deg, #e74c3c 0%, #c0392b 100%);
        }
        
        /* Tables */
        .table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 30px;
        }
        
        .table-header {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
            color: white;
            padding: 15px 20px;
            font-weight: bold;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th {
            background: #f8f9fa;
            padding: 12px 15px;
            text-align: right;
            font-weight: bold;
            font-size: 13px;
        }
        
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 13px;
        }
        
        tbody tr:hover {
            background: #f8f9fa;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
        }
        
        .badge-in { background: #d4edda; color: #155724; }
        .badge-out { background: #f8d7da; color: #721c24; }
        .badge-transfer { background: #d1ecf1; color: #0c5460; }
        .badge-adjustment { background: #e2e3e5; color: #383d41; }
        
        .badge-pending { background: #fff3cd; color: #856404; }
        .badge-approved { background: #d1ecf1; color: #0c5460; }
        .badge-completed { background: #d4edda; color: #155724; }
        .badge-rejected { background: #f8d7da; color: #721c24; }
        
        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            display: inline-block;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            color: white;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #f39c12 0%, #e67e22 100%);
        }
        
        .btn-success {
            background: linear-gradient(135deg, #27ae60 0%, #229954 100%);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }
        
        @media (max-width: 768px) {
            .warehouses-grid,
            .alert-cards {
                grid-template-columns: 1fr;
            }
            
            .table-container {
                overflow-x: auto;
            }
            
            table {
                min-width: 800px;
            }
        }
    </style>
</head>
<body>
    <div class="warehouse-container">
        <!-- Warehouse Header -->
        <div class="warehouse-header">
            <h1>📦 داشبورد انبارداری</h1>
            <p>مدیریت انبارها، موجودی و تراکنش‌های کالا</p>
        </div>
        
        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo en2fa($warehouseStats['total_warehouses']); ?></h3>
                <p>تعداد انبارها</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo en2fa($warehouseStats['total_items']); ?></h3>
                <p>کل اقلام</p>
            </div>
            
            <div class="stat-card warning">
                <h3><?php echo en2fa($warehouseStats['low_stock_items']); ?></h3>
                <p>موجودی کم</p>
            </div>
            
            <div class="stat-card danger">
                <h3><?php echo en2fa($warehouseStats['out_of_stock']); ?></h3>
                <p>تمام شده</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo en2fa($warehouseStats['transactions_today']); ?></h3>
                <p>تراکنش امروز</p>
            </div>
            
            <div class="stat-card">
                <h3><?php echo en2fa(number_format($totalInventoryValue['total_value'] ?? 0)); ?></h3>
                <p>ارزش موجودی (ریال)</p>
            </div>
        </div>
        
        <!-- Action Buttons -->
        <div class="action-buttons">
            <a href="warehouse_items.php" class="btn btn-primary">📋 مدیریت اقلام</a>
            <a href="warehouse_transaction.php?action=in" class="btn btn-success">📥 ورود به انبار</a>
            <a href="warehouse_transaction.php?action=out" class="btn btn-danger">📤 خروج از انبار</a>
            <a href="warehouse_reports.php" class="btn btn-primary">📊 گزارشات</a>
        </div>
        
        <!-- Warehouses -->
        <h2 style="margin: 30px 0 20px;">🏢 انبارهای فعال</h2>
        <div class="warehouses-grid">
            <?php foreach ($warehouses as $warehouse): 
                $icons = ['main' => '🏢', 'site' => '🏗️', 'waste' => '♻️', 'project' => '📊', 'electronic' => '💻'];
            ?>
                <div class="warehouse-card">
                    <div class="warehouse-icon"><?php echo $icons[$warehouse['type']] ?? '📦'; ?></div>
                    <div class="warehouse-name"><?php echo h($warehouse['name']); ?></div>
                    <div style="font-size: 13px; color: #7f8c8d; margin-bottom: 10px;">
                        📍 <?php echo h($warehouse['location'] ?: 'نامشخص'); ?>
                        <br>
                        👤 مدیر: <?php echo h($warehouse['manager_name'] ?: 'تعیین نشده'); ?>
                    </div>
                    <div class="warehouse-info">
                        <div class="warehouse-stat">
                            <div class="warehouse-stat-value"><?php echo en2fa($warehouse['total_items']); ?></div>
                            <div class="warehouse-stat-label">کل اقلام</div>
                        </div>
                        <div class="warehouse-stat">
                            <div class="warehouse-stat-value"><?php echo en2fa($warehouse['active_items_week']); ?></div>
                            <div class="warehouse-stat-label">فعال این هفته</div>
                        </div>
                    </div>
                    <a href="warehouse_detail.php?id=<?php echo $warehouse['id']; ?>" 
                       style="display: block; margin-top: 15px; text-align: center; color: #f39c12; text-decoration: none; font-weight: bold;">
                        مشاهده جزئیات →
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Alerts -->
        <div class="alert-section">
            <h2 style="margin-bottom: 20px;">⚠️ هشدارهای انبار</h2>
            <div class="alert-cards">
                <!-- Low Stock Items -->
                <div class="alert-card">
                    <div class="alert-header warning">
                        ⚠️ اقلام با موجودی کم (<?php echo en2fa(count($lowStockItems)); ?>)
                    </div>
                    <div class="alert-body">
                        <?php if (count($lowStockItems) > 0): ?>
                            <?php foreach ($lowStockItems as $item): 
                                $stockPercent = $item['min_stock'] > 0 ? ($item['current_stock'] / $item['min_stock']) * 100 : 0;
                            ?>
                                <div class="alert-item">
                                    <div class="alert-item-name"><?php echo h($item['name']); ?></div>
                                    <div class="alert-item-info">
                                        <span>
                                            موجودی: <?php echo en2fa(number_format($item['current_stock'], 2)); ?> 
                                            / 
                                            <?php echo en2fa(number_format($item['min_stock'], 2)); ?>
                                            <?php echo h($item['unit']); ?>
                                        </span>
                                    </div>
                                    <div class="stock-info" style="margin-top: 8px;">
                                        <div class="progress-bar">
                                            <div class="progress-fill low" style="width: <?php echo min(100, $stockPercent); ?>%"></div>
                                        </div>
                                        <span style="font-size: 12px; color: #f39c12;">
                                            <?php echo en2fa(round($stockPercent)); ?>%
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                ✅ همه اقلام موجودی کافی دارند
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Out of Stock -->
                <div class="alert-card">
                    <div class="alert-header danger">
                        🚨 اقلام تمام شده (<?php echo en2fa(count($outOfStockItems)); ?>)
                    </div>
                    <div class="alert-body">
                        <?php if (count($outOfStockItems) > 0): ?>
                            <?php foreach ($outOfStockItems as $item): ?>
                                <div class="alert-item danger">
                                    <div class="alert-item-name"><?php echo h($item['name']); ?></div>
                                    <div class="alert-item-info">
                                        <span>کد: <?php echo h($item['code']); ?></span>
                                        <span style="color: #e74c3c; font-weight: bold;">موجودی: ۰</span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                ✅ اقلام تمام شده‌ای وجود ندارد
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <?php if (check_permission('warehouse', PERMISSION_WRITE) && count($pendingRequests) > 0): ?>
        <!-- Pending Requests -->
        <div class="table-container">
            <div class="table-header">
                ⏳ درخواست‌های در انتظار تایید
                <span><?php echo en2fa(count($pendingRequests)); ?> مورد</span>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>نوع</th>
                        <th>انبار</th>
                        <th>کالا</th>
                        <th>مقدار</th>
                        <th>موجودی فعلی</th>
                        <th>پروژه</th>
                        <th>درخواست‌کننده</th>
                        <th>تاریخ</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pendingRequests as $req): ?>
                        <tr>
                            <td>
                                <span class="badge badge-<?php echo $req['type']; ?>">
                                    <?php 
                                    $types = ['in' => 'ورود', 'out' => 'خروج', 'transfer' => 'انتقال', 'adjustment' => 'تعدیل'];
                                    echo $types[$req['type']] ?? $req['type'];
                                    ?>
                                </span>
                            </td>
                            <td><?php echo h($req['warehouse_name']); ?></td>
                            <td><?php echo h($req['item_name']); ?></td>
                            <td>
                                <?php echo en2fa(number_format($req['quantity'], 2)); ?>
                                <?php echo h($req['unit']); ?>
                            </td>
                            <td>
                                <?php echo en2fa(number_format($req['current_stock'], 2)); ?>
                                <?php echo h($req['unit']); ?>
                            </td>
                            <td><?php echo h($req['project_name'] ?: '-'); ?></td>
                            <td><?php echo h($req['requested_by_name']); ?></td>
                            <td><?php echo en2fa(date('Y/m/d', strtotime($req['created_at']))); ?></td>
                            <td>
                                <?php if (check_permission('warehouse', PERMISSION_FULL)): ?>
                                    <a href="warehouse_transaction.php?action=approve&id=<?php echo $req['id']; ?>" 
                                       style="color: #27ae60; text-decoration: none;">✓</a>
                                    |
                                    <a href="warehouse_transaction.php?action=reject&id=<?php echo $req['id']; ?>" 
                                       style="color: #e74c3c; text-decoration: none;">✗</a>
                                <?php else: ?>
                                    <a href="warehouse_transaction.php?action=view&id=<?php echo $req['id']; ?>" 
                                       style="color: #3498db; text-decoration: none;">👁</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
        
        <!-- Recent Transactions -->
        <div class="table-container">
            <div class="table-header">
                📋 آخرین تراکنش‌ها
                <a href="warehouse_transactions.php" style="color: white; text-decoration: none; font-size: 13px;">
                    مشاهده همه
                </a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>نوع</th>
                        <th>انبار</th>
                        <th>کالا</th>
                        <th>مقدار</th>
                        <th>وضعیت</th>
                        <th>درخواست‌کننده</th>
                        <th>تاریخ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTransactions as $trans): ?>
                        <tr>
                            <td>
                                <span class="badge badge-<?php echo $trans['type']; ?>">
                                    <?php 
                                    $types = ['in' => 'ورود', 'out' => 'خروج', 'transfer' => 'انتقال', 'adjustment' => 'تعدیل'];
                                    echo $types[$trans['type']] ?? $trans['type'];
                                    ?>
                                </span>
                            </td>
                            <td><?php echo h($trans['warehouse_name']); ?></td>
                            <td><?php echo h($trans['item_name']); ?></td>
                            <td>
                                <?php echo en2fa(number_format($trans['quantity'], 2)); ?>
                                <?php echo h($trans['unit']); ?>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $trans['status']; ?>">
                                    <?php 
                                    $statuses = ['pending' => 'در انتظار', 'approved' => 'تایید شده', 'completed' => 'انجام شده', 'rejected' => 'رد شده'];
                                    echo $statuses[$trans['status']] ?? $trans['status'];
                                    ?>
                                </span>
                            </td>
                            <td><?php echo h($trans['requested_by_name'] ?: '-'); ?></td>
                            <td><?php echo en2fa(date('Y/m/d', strtotime($trans['transaction_date']))); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php require_once 'footer.php'; ?>